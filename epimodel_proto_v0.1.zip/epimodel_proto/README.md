# EpiModel prototype v0.1 — Methods text → environment spec

First test case: Gollwitzer et al. (2024), hydrocephalus prediction (PMID 39276974).

## What it does
1. **decompose** (LLM): reads `data/methods_input.txt` and extracts the analysis plan as JSON.
2. **dependencies** (LLM): lists the Python packages needed (stated vs inferred) and open questions for the user.
3. **evaluate** (no LLM): compares the result with `data/answer_key.json`, which was built from the authors' real code.

## Run
1. Install Ollama: https://ollama.com/download
2. Download a model: `ollama pull llama3.1:8b`
3. Install Python packages (Python 3.10+):
   ```
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Check the pipeline without a model: `python prototype.py --mock`
5. Real run: `python prototype.py` (or `--model qwen2.5:7b` to try another model)

Each run saves its full output to `results/run_<time>_<model>.json`.
